package com.training.auditLog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuditLogApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuditLogApplication.class, args);
	}
}
