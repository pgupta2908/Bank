package com.training.banking.controller;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.banking.model.Account;
import com.training.banking.service.IAccountService;
import com.training.banking.wrappers.AccountWrapper;

@RestController
@RequestMapping(value = "/account")
public class AccountController {

	@Autowired
	IAccountService accountService;

	@PostMapping(value = "/create")
	public ResponseEntity<Account> createAccount(@RequestBody AccountWrapper accountWrapper) {
		Account createdAccount = accountService.createAccount(accountWrapper);
		return new ResponseEntity<Account>(createdAccount, HttpStatus.CREATED);
	}

	@PostMapping(value = "/deposit")
	public ResponseEntity<Account> depositMoney(Integer accountId, BigDecimal amount/*, Integer bankId,
			Integer customerId*/) {
		Account updatedAccount = accountService.depositMoney(accountId, amount/*, bankId, customerId*/);
		return new ResponseEntity<Account>(updatedAccount, HttpStatus.ACCEPTED) ;

	}

	@PostMapping(value = "/withdraw")
	public ResponseEntity<String> withdrawMoney(Integer accountId, BigDecimal amount) {
		return null;

	}

	@GetMapping(value = "/getById")
	public ResponseEntity<Optional<Account>> getAccountDetails(@RequestParam Integer accountId) {
		Optional<Account> account = accountService.getAccountDetails(accountId);
		return new ResponseEntity<Optional<Account>>(account, HttpStatus.FOUND);
	}

}
