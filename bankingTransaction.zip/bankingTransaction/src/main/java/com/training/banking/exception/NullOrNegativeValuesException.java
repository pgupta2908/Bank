package com.training.banking.exception;

public class NullOrNegativeValuesException extends Exception {

	private static final long serialVersionUID = 1L;

	public NullOrNegativeValuesException(String message) {
		super(message);
	}

}
