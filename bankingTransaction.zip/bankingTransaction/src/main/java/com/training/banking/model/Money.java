package com.training.banking.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Money {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "denomination_id")
	private Integer denominationId;

	@Column(name = "denomination")
	private BigDecimal denomination;

	@Column(name = "count")
	private Integer count;

	public Integer getDenominationId() {
		return denominationId;
	}

	public void setDenominationId(Integer denominationId) {
		this.denominationId = denominationId;
	}

	public BigDecimal getDenomination() {
		return denomination;
	}

	public void setDenomination(BigDecimal denomination) {
		this.denomination = denomination;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Money() {
		super();
	}

	public Money(BigDecimal denomination, Integer count) {
		super();
		this.denomination = denomination;
		this.count = count;
	}

	public Money(Integer denominationId, BigDecimal denomination, Integer count) {
		super();
		this.denominationId = denominationId;
		this.denomination = denomination;
		this.count = count;
	}

	@Override
	public String toString() {
		return "Money [denominationId=" + denominationId + ", denomination=" + denomination + ", count=" + count + "]";
	}

}
