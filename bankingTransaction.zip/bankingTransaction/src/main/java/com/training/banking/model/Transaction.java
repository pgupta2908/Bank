package com.training.banking.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Table(name="Transaction")
@Entity
@Data
public class Transaction {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="transaction_id")
	private Integer transactionId;
	
	@Column(name="customer_id")
	private Integer customerId;
	
	@Column(name="account_id")
	private Integer accountId;
	
	@Column(name="amount")
	private BigDecimal amount;
	
	@Column(name="transaction_type")
	private String transactionType;

}
