package com.training.banking.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.banking.repository.IATMRepository;

public class ATMServiceImpl implements IATMService{

	@Autowired
	IATMRepository atmRepo;
	
}
