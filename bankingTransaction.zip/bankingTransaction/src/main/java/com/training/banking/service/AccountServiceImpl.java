package com.training.banking.service;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.banking.model.Account;
import com.training.banking.model.Bank;
import com.training.banking.model.Customer;
import com.training.banking.repository.IAccountRepository;
import com.training.banking.repository.IBankRepository;
import com.training.banking.repository.ICustomerRepository;
import com.training.banking.wrappers.AccountWrapper;

@Service
public class AccountServiceImpl implements IAccountService {

	@Autowired
	IAccountRepository accountRepo;

	@Autowired
	ICustomerRepository customerRepo;

	@Autowired
	IBankRepository bankRepo;

	@Override
	public Account createAccount(AccountWrapper accountWrapper) {

		Integer bankId = accountWrapper.getBankId();
		Optional<Bank> bankPossible = bankRepo.findById(bankId);
		Bank bank = bankPossible.get();
		Integer customerId = accountWrapper.getCustomerId();
		Optional<Customer> customerPossible = customerRepo.findById(customerId);
		Customer customer = customerPossible.get();
		Account account = accountWrapper.getAccount();
		account.setBank(bank);
		account.setCustomer(customer);
		accountRepo.save(account);
		return account;
	}

	@Override
	public Account depositMoney(@RequestParam Integer accountId, @RequestParam BigDecimal amount/*, Integer bankId, Integer customerId*/) {
		
		Optional<Account> accountPossible = accountRepo.findById(accountId);
		Account account = accountPossible.get();
		BigDecimal initialBalance = account.getAmount();
		BigDecimal updatedBalance = initialBalance.subtract(amount);
		
		return account;
	}

	@Override
	public ResponseEntity<String> withdrawMoney(Integer accountId, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Account> getAccountDetails(Integer accountId) {

		return accountRepo.findById(accountId);
	}

}
