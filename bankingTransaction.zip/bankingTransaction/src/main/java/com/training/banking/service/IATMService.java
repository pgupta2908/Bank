package com.training.banking.service;

public interface IATMService {

}
