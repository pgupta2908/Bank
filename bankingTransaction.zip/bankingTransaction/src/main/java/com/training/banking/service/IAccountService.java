package com.training.banking.service;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.training.banking.model.Account;
import com.training.banking.wrappers.AccountWrapper;

public interface IAccountService {

	public Account createAccount(AccountWrapper accountWrapper);

	public Account depositMoney(Integer accountId, BigDecimal amount/*, Integer bankId, Integer customerId*/);

	public ResponseEntity<String> withdrawMoney(Integer accountId, BigDecimal amount);

	public Optional<Account> getAccountDetails(Integer accountId);

}
