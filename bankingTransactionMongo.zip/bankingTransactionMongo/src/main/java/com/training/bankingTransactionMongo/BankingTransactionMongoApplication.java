package com.training.bankingTransactionMongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingTransactionMongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingTransactionMongoApplication.class, args);
	}
}
